import 'package:flutter_test/flutter_test.dart';
import 'package:n/core/theme/app_theme.dart';
import 'package:n/core/utils/date_formatter.dart';
import 'package:n/features/notes/data/models/note_model.dart';
import 'package:n/features/notes/domain/entities/note.dart';

void main() {
  group('DateFormatter Tests', () {
    test('formatForExport produces correct filename', () {
      final dateTime = DateTime(2026, 6, 26, 14, 35, 18);
      final filename = DateFormatter.formatForExport(dateTime);
      expect(filename, '2026-06-26_14-35-18.md');
    });

    test('formatForDisplay produces readable string', () {
      final dateTime = DateTime(2026, 6, 26, 14, 35, 18);
      final displayStr = DateFormatter.formatForDisplay(dateTime);
      expect(displayStr, '26 Jun 2026, 14:35');
    });
  });

  group('NoteModel Mapping Tests', () {
    test('toMap serializes note fields correctly', () {
      final createdAt = DateTime(2026, 6, 26, 14, 30);
      final note = Note(
        id: 42,
        uuid: 'test-uuid-123',
        text: 'Hello, this is a minimalist thought.',
        createdAt: createdAt,
        isDeleted: true,
        deletedAt: createdAt.add(const Duration(minutes: 5)),
      );

      final model = NoteModel.fromEntity(note);
      final map = model.toMap();

      expect(map['id'], 42);
      expect(map['uuid'], 'test-uuid-123');
      expect(map['text'], 'Hello, this is a minimalist thought.');
      expect(map['created_at'], createdAt.millisecondsSinceEpoch);
      expect(map['is_deleted'], 1);
      expect(map['deleted_at'], createdAt.add(const Duration(minutes: 5)).millisecondsSinceEpoch);
    });

    test('fromMap deserializes database map correctly', () {
      final createdAtEpoch = DateTime(2026, 6, 26, 14, 30).millisecondsSinceEpoch;
      final deletedAtEpoch = DateTime(2026, 6, 26, 14, 35).millisecondsSinceEpoch;
      
      final dbMap = {
        'id': 99,
        'uuid': 'another-uuid-456',
        'text': 'A thought to delete.',
        'created_at': createdAtEpoch,
        'updated_at': null,
        'is_deleted': 1,
        'deleted_at': deletedAtEpoch,
      };

      final model = NoteModel.fromMap(dbMap);

      expect(model.id, 99);
      expect(model.uuid, 'another-uuid-456');
      expect(model.text, 'A thought to delete.');
      expect(model.createdAt.millisecondsSinceEpoch, createdAtEpoch);
      expect(model.updatedAt, isNull);
      expect(model.isDeleted, true);
      expect(model.deletedAt!.millisecondsSinceEpoch, deletedAtEpoch);
    });
  });

  group('AppTheme Configuration Tests', () {
    test('AppFontSize scale factors are correct', () {
      expect(AppFontSize.small.scaleFactor, 0.85);
      expect(AppFontSize.medium.scaleFactor, 1.0);
      expect(AppFontSize.large.scaleFactor, 1.25);
      expect(AppFontSize.extraLarge.scaleFactor, 1.5);
    });

    test('AppFontSize fromString fallback logic works', () {
      expect(AppFontSizeExtension.fromString('small'), AppFontSize.small);
      expect(AppFontSizeExtension.fromString('extraLarge'), AppFontSize.extraLarge);
      expect(AppFontSizeExtension.fromString('invalid_size'), AppFontSize.medium);
    });
  });
}
