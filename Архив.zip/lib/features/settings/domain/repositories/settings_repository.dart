abstract class SettingsRepository {
  Future<String> getThemeMode();
  Future<void> setThemeMode(String themeMode);
  Future<String> getFontSize();
  Future<void> setFontSize(String fontSize);
}
