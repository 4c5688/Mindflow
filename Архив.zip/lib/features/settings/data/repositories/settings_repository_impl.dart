import 'package:sqflite/sqflite.dart';
import '../../../../core/database/database_helper.dart';
import '../../domain/repositories/settings_repository.dart';

class SettingsRepositoryImpl implements SettingsRepository {
  final DatabaseHelper _dbHelper;

  SettingsRepositoryImpl({DatabaseHelper? dbHelper})
      : _dbHelper = dbHelper ?? DatabaseHelper.instance;

  @override
  Future<String> getThemeMode() async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'settings',
      where: 'key = ?',
      whereArgs: ['theme_mode'],
    );
    if (maps.isNotEmpty) {
      return maps.first['value'] as String;
    }
    return 'system';
  }

  @override
  Future<void> setThemeMode(String themeMode) async {
    final db = await _dbHelper.database;
    await db.insert(
      'settings',
      {'key': 'theme_mode', 'value': themeMode},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  @override
  Future<String> getFontSize() async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'settings',
      where: 'key = ?',
      whereArgs: ['font_size'],
    );
    if (maps.isNotEmpty) {
      return maps.first['value'] as String;
    }
    return 'medium';
  }

  @override
  Future<void> setFontSize(String fontSize) async {
    final db = await _dbHelper.database;
    await db.insert(
      'settings',
      {'key': 'font_size', 'value': fontSize},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }
}
