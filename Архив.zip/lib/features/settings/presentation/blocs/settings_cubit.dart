import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../notes/domain/repositories/notes_repository.dart';
import '../../domain/repositories/settings_repository.dart';
import 'settings_state.dart';

class SettingsCubit extends Cubit<SettingsState> {
  final SettingsRepository _settingsRepository;
  final NotesRepository _notesRepository;

  SettingsCubit(this._settingsRepository, this._notesRepository)
      : super(const SettingsState()) {
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final theme = await _settingsRepository.getThemeMode();
    final fontStr = await _settingsRepository.getFontSize();
    final fontSize = AppFontSizeExtension.fromString(fontStr);
    
    emit(state.copyWith(
      themeMode: theme,
      fontSize: fontSize,
    ));
  }

  Future<void> updateThemeMode(String theme) async {
    await _settingsRepository.setThemeMode(theme);
    emit(state.copyWith(themeMode: theme));
  }

  Future<void> updateFontSize(AppFontSize fontSize) async {
    await _settingsRepository.setFontSize(fontSize.name);
    emit(state.copyWith(fontSize: fontSize));
  }

  Future<void> exportNotes() async {
    emit(state.copyWith(isExporting: true));
    try {
      // Get all active (non-deleted) notes
      final notes = await _notesRepository.getAllActiveNotes();
      
      if (notes.isEmpty) {
        throw Exception('No active notes to export');
      }

      final archive = Archive();
      for (final note in notes) {
        final filename = DateFormatter.formatForExport(note.createdAt);
        // Include creation date and raw note text
        final fileContent = 'Created: ${DateFormatter.formatForDisplay(note.createdAt)}\n\n${note.text}';
        final bytes = utf8.encode(fileContent);
        final archiveFile = ArchiveFile(filename, bytes.length, bytes);
        archive.addFile(archiveFile);
      }
      
      final zipData = ZipEncoder().encode(archive);
      if (zipData == null) throw Exception('Failed to encode ZIP archive');

      final tempDir = await getTemporaryDirectory();
      final file = File('${tempDir.path}/notes-export.zip');
      await file.writeAsBytes(zipData);

      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'application/zip')],
        subject: 'Notes Export',
      );

      emit(state.copyWith(
        isExporting: false,
        exportPath: file.path,
      ));
    } catch (e) {
      emit(state.copyWith(
        isExporting: false,
        errorMessage: e.toString(),
      ));
    }
  }
}
