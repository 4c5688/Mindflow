import '../../../../core/theme/app_theme.dart';

class SettingsState {
  final String themeMode; // 'system', 'light', 'dark'
  final AppFontSize fontSize;
  final bool isExporting;
  final String? exportPath;
  final String? errorMessage;

  const SettingsState({
    this.themeMode = 'system',
    this.fontSize = AppFontSize.medium,
    this.isExporting = false,
    this.exportPath,
    this.errorMessage,
  });

  SettingsState copyWith({
    String? themeMode,
    AppFontSize? fontSize,
    bool? isExporting,
    String? exportPath,
    String? errorMessage,
  }) {
    return SettingsState(
      themeMode: themeMode ?? this.themeMode,
      fontSize: fontSize ?? this.fontSize,
      isExporting: isExporting ?? this.isExporting,
      exportPath: exportPath,
      errorMessage: errorMessage,
    );
  }
}
