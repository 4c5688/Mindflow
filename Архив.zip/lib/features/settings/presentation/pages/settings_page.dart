import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../trash/presentation/pages/trash_page.dart';
import '../blocs/settings_cubit.dart';
import '../blocs/settings_state.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SettingsCubit, SettingsState>(
      builder: (context, state) {
        final fontSize = state.fontSize;
        final scale = fontSize.scaleFactor;

        return CupertinoPageScaffold(
          navigationBar: CupertinoNavigationBar(
            middle: Text(
              'Settings',
              style: TextStyle(
                fontFamily: '.SF Pro Display',
                fontSize: 18 * scale,
                fontWeight: FontWeight.w600,
              ),
            ),
            previousPageTitle: 'Write',
          ),
          child: SafeArea(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
              children: [
                Text(
                  'Appearance',
                  style: TextStyle(
                    fontFamily: '.SF Pro Text',
                    fontSize: 13 * scale,
                    fontWeight: FontWeight.w500,
                    color: CupertinoColors.secondaryLabel.resolveFrom(context),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: CupertinoSlidingSegmentedControl<String>(
                        groupValue: state.themeMode,
                        children: {
                          'system': Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Text('System', style: TextStyle(fontSize: 13 * scale)),
                          ),
                          'light': Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Text('Light', style: TextStyle(fontSize: 13 * scale)),
                          ),
                          'dark': Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Text('Dark', style: TextStyle(fontSize: 13 * scale)),
                          ),
                        },
                        onValueChanged: (val) {
                          if (val != null) {
                            context.read<SettingsCubit>().updateThemeMode(val);
                          }
                        },
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 28),

                Text(
                  'Font Size',
                  style: TextStyle(
                    fontFamily: '.SF Pro Text',
                    fontSize: 13 * scale,
                    fontWeight: FontWeight.w500,
                    color: CupertinoColors.secondaryLabel.resolveFrom(context),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: CupertinoSlidingSegmentedControl<AppFontSize>(
                        groupValue: state.fontSize,
                        children: {
                          AppFontSize.small: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Text('Small', style: TextStyle(fontSize: 12 * scale)),
                          ),
                          AppFontSize.medium: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Text('Default', style: TextStyle(fontSize: 12 * scale)),
                          ),
                          AppFontSize.large: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Text('Large', style: TextStyle(fontSize: 12 * scale)),
                          ),
                          AppFontSize.extraLarge: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Text('Extra', style: TextStyle(fontSize: 12 * scale)),
                          ),
                        },
                        onValueChanged: (val) {
                          if (val != null) {
                            context.read<SettingsCubit>().updateFontSize(val);
                          }
                        },
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 36),
                Container(
                  height: 0.5,
                  color: CupertinoColors.separator.resolveFrom(context),
                ),
                const SizedBox(height: 16),

                CupertinoButton(
                  padding: EdgeInsets.zero,
                  alignment: Alignment.centerLeft,
                  onPressed: () {
                    Navigator.push(
                      context,
                      CupertinoPageRoute(
                        builder: (_) => const TrashPage(),
                      ),
                    );
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Recently Deleted',
                        style: TextStyle(
                          fontFamily: '.SF Pro Text',
                          fontSize: 16 * scale,
                          color: CupertinoTheme.of(context).textTheme.textStyle.color,
                        ),
                      ),
                      Icon(
                        CupertinoIcons.right_chevron,
                        size: 16,
                        color: CupertinoColors.secondaryLabel.resolveFrom(context),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 8),
                Container(
                  height: 0.5,
                  color: CupertinoColors.separator.resolveFrom(context),
                ),
                const SizedBox(height: 16),

                CupertinoButton(
                  padding: EdgeInsets.zero,
                  alignment: Alignment.centerLeft,
                  onPressed: state.isExporting
                      ? null
                      : () => context.read<SettingsCubit>().exportNotes(),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        state.isExporting ? 'Exporting...' : 'Export Notes (ZIP)',
                        style: TextStyle(
                          fontFamily: '.SF Pro Text',
                          fontSize: 16 * scale,
                          color: state.isExporting
                              ? CupertinoColors.inactiveGray
                              : CupertinoTheme.of(context).primaryColor,
                        ),
                      ),
                      if (state.isExporting)
                        const CupertinoActivityIndicator()
                      else
                        Icon(
                          CupertinoIcons.share,
                          size: 18,
                          color: CupertinoTheme.of(context).primaryColor,
                        ),
                    ],
                  ),
                ),

                const SizedBox(height: 8),
                Container(
                  height: 0.5,
                  color: CupertinoColors.separator.resolveFrom(context),
                ),
                
                if (state.errorMessage != null) ...[
                  const SizedBox(height: 24),
                  Text(
                    state.errorMessage!,
                    style: TextStyle(
                      fontFamily: '.SF Pro Text',
                      fontSize: 14 * scale,
                      color: CupertinoColors.destructiveRed,
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}
