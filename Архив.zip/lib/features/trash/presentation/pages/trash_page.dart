import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../notes/domain/entities/note.dart';
import '../../../notes/presentation/blocs/notes_cubit.dart';
import '../../../notes/presentation/blocs/notes_state.dart';
import '../../../settings/presentation/blocs/settings_cubit.dart';
import '../../../settings/presentation/blocs/settings_state.dart';

class TrashPage extends StatelessWidget {
  const TrashPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SettingsCubit, SettingsState>(
      builder: (context, settingsState) {
        final fontSize = settingsState.fontSize;
        final scale = fontSize.scaleFactor;

        return CupertinoPageScaffold(
          navigationBar: CupertinoNavigationBar(
            middle: Text(
              'Recently Deleted',
              style: TextStyle(
                fontFamily: '.SF Pro Display',
                fontSize: 18 * scale,
                fontWeight: FontWeight.w600,
              ),
            ),
            previousPageTitle: 'Settings',
            trailing: CupertinoButton(
              padding: EdgeInsets.zero,
              child: Text(
                'Clean All',
                style: TextStyle(fontSize: 15 * scale),
              ),
              onPressed: () => _showCleanConfirmDialog(context, scale),
            ),
          ),
          child: SafeArea(
            child: BlocBuilder<NotesCubit, NotesState>(
              builder: (context, notesState) {
                final notes = notesState.softDeletedNotes;
                
                if (notes.isEmpty) {
                  return Center(
                    child: Text(
                      'No recently deleted notes.',
                      style: AppTheme.dateTextStyle(
                        CupertinoTheme.of(context).brightness,
                        fontSize,
                      ),
                    ),
                  );
                }

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        'Notes are kept here for 30 days before being permanently deleted.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: '.SF Pro Text',
                          fontSize: 13 * scale,
                          color: CupertinoColors.secondaryLabel.resolveFrom(context),
                          height: 1.4,
                        ),
                      ),
                    ),
                    Expanded(
                      child: ListView.separated(
                        itemCount: notes.length,
                        separatorBuilder: (context, index) => Container(
                          height: 0.5,
                          color: CupertinoColors.separator.resolveFrom(context),
                          margin: const EdgeInsets.only(left: 16.0),
                        ),
                        itemBuilder: (context, index) {
                          final note = notes[index];
                          return GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: () => _showNoteActions(context, note, fontSize),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 14.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    note.text,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontFamily: '.SF Pro Text',
                                      fontSize: 16 * scale,
                                      height: 1.4,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    'Deleted: ${DateFormatter.formatForDisplay(note.deletedAt ?? note.createdAt)}',
                                    style: AppTheme.dateTextStyle(
                                      CupertinoTheme.of(context).brightness,
                                      fontSize,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        );
      },
    );
  }

  void _showNoteActions(BuildContext context, Note note, AppFontSize fontSize) {
    showCupertinoModalPopup(
      context: context,
      builder: (actionSheetContext) => CupertinoActionSheet(
        title: Text(
          note.text,
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 14 * fontSize.scaleFactor,
          ),
        ),
        actions: [
          CupertinoActionSheetAction(
            child: const Text('Restore Note'),
            onPressed: () {
              context.read<NotesCubit>().restore(note.uuid);
              Navigator.pop(actionSheetContext);
            },
          ),
          CupertinoActionSheetAction(
            isDestructiveAction: true,
            onPressed: () {
              context.read<NotesCubit>().hardDelete(note.uuid);
              Navigator.pop(actionSheetContext);
            },
            child: const Text('Delete Forever'),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          child: const Text('Cancel'),
          onPressed: () {
            Navigator.pop(actionSheetContext);
          },
        ),
      ),
    );
  }

  void _showCleanConfirmDialog(BuildContext context, double scale) {
    showCupertinoDialog(
      context: context,
      builder: (dialogContext) => CupertinoAlertDialog(
        title: Text('Empty Trash', style: TextStyle(fontSize: 17 * scale)),
        content: Text(
          'Are you sure you want to permanently delete all expired soft-deleted notes older than 30 days?',
          style: TextStyle(fontSize: 13 * scale),
        ),
        actions: [
          CupertinoDialogAction(
            child: const Text('Cancel'),
            onPressed: () => Navigator.pop(dialogContext),
          ),
          CupertinoDialogAction(
            isDestructiveAction: true,
            onPressed: () {
              context.read<NotesCubit>().cleanTrash();
              Navigator.pop(dialogContext);
            },
            child: const Text('Clean'),
          ),
        ],
      ),
    );
  }
}
