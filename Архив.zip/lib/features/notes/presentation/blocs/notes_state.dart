import '../../domain/entities/note.dart';

class NotesState {
  final List<Note> activeNotes;
  final List<Note> recentNotes;
  final List<Note> softDeletedNotes;
  final String searchQuery;
  final String sortBy; // 'newest', 'oldest', 'length'
  final bool isLoading;
  final String? errorMessage;

  const NotesState({
    this.activeNotes = const [],
    this.recentNotes = const [],
    this.softDeletedNotes = const [],
    this.searchQuery = '',
    this.sortBy = 'newest',
    this.isLoading = false,
    this.errorMessage,
  });

  NotesState copyWith({
    List<Note>? activeNotes,
    List<Note>? recentNotes,
    List<Note>? softDeletedNotes,
    String? searchQuery,
    String? sortBy,
    bool? isLoading,
    String? errorMessage,
  }) {
    return NotesState(
      activeNotes: activeNotes ?? this.activeNotes,
      recentNotes: recentNotes ?? this.recentNotes,
      softDeletedNotes: softDeletedNotes ?? this.softDeletedNotes,
      searchQuery: searchQuery ?? this.searchQuery,
      sortBy: sortBy ?? this.sortBy,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage,
    );
  }
}
