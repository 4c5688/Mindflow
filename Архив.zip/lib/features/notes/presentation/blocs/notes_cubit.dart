import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:uuid/uuid.dart';
import '../../domain/entities/note.dart';
import '../../domain/repositories/notes_repository.dart';
import 'notes_state.dart';

class NotesCubit extends Cubit<NotesState> {
  final NotesRepository _repository;
  final _uuidGen = const Uuid();

  NotesCubit(this._repository) : super(const NotesState()) {
    loadAllData();
  }

  /// Reloads all notes (active, recent 5, and soft-deleted) from the repository
  Future<void> loadAllData() async {
    emit(state.copyWith(isLoading: true));
    try {
      final recents = await _repository.getRecentNotes(5);
      final active = await _repository.getAllActiveNotes(
        searchQuery: state.searchQuery,
        sortBy: state.sortBy,
      );
      final trash = await _repository.getSoftDeletedNotes();

      emit(state.copyWith(
        activeNotes: active,
        recentNotes: recents,
        softDeletedNotes: trash,
        isLoading: false,
      ));
    } catch (e) {
      emit(state.copyWith(
        isLoading: false,
        errorMessage: e.toString(),
      ));
    }
  }

  /// Saves a new note asynchronously.
  Future<void> saveNoteText(String text) async {
    if (text.trim().isEmpty) return;

    final newNote = Note(
      uuid: _uuidGen.v4(),
      text: text,
      createdAt: DateTime.now(),
    );

    // Save asynchronously to SQLite DB
    // We update local state first/asynchronously to keep UI completely non-blocking
    try {
      await _repository.saveNote(newNote);
      // Refresh data
      await loadAllData();
    } catch (e) {
      emit(state.copyWith(errorMessage: e.toString()));
    }
  }

  /// Triggers a soft delete of a note by UUID
  Future<void> softDelete(String uuid) async {
    try {
      await _repository.softDeleteNote(uuid);
      await loadAllData();
    } catch (e) {
      emit(state.copyWith(errorMessage: e.toString()));
    }
  }

  /// Restores a soft-deleted note by UUID
  Future<void> restore(String uuid) async {
    try {
      await _repository.restoreNote(uuid);
      await loadAllData();
    } catch (e) {
      emit(state.copyWith(errorMessage: e.toString()));
    }
  }

  /// Permanently deletes a note by UUID
  Future<void> hardDelete(String uuid) async {
    try {
      await _repository.hardDeleteNote(uuid);
      await loadAllData();
    } catch (e) {
      emit(state.copyWith(errorMessage: e.toString()));
    }
  }

  /// Updates the active search query and reloads active notes
  Future<void> updateSearch(String query) async {
    emit(state.copyWith(searchQuery: query));
    final active = await _repository.getAllActiveNotes(
      searchQuery: query,
      sortBy: state.sortBy,
    );
    emit(state.copyWith(activeNotes: active));
  }

  /// Updates the sorting criteria and reloads active notes
  Future<void> updateSort(String sortBy) async {
    emit(state.copyWith(sortBy: sortBy));
    final active = await _repository.getAllActiveNotes(
      searchQuery: state.searchQuery,
      sortBy: sortBy,
    );
    emit(state.copyWith(activeNotes: active));
  }

  /// Manually clears expired trash (older than 30 days) and reloads
  Future<void> cleanTrash() async {
    try {
      await _repository.hardDeleteAllExpiredTrash();
      await loadAllData();
    } catch (e) {
      emit(state.copyWith(errorMessage: e.toString()));
    }
  }
}
