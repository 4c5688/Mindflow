import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart' show Dismissible, DismissDirection;
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../settings/presentation/blocs/settings_cubit.dart';
import '../../../settings/presentation/blocs/settings_state.dart';
import '../blocs/notes_cubit.dart';
import '../blocs/notes_state.dart';

class AllNotesPage extends StatefulWidget {
  const AllNotesPage({super.key});

  @override
  State<AllNotesPage> createState() => _AllNotesPageState();
}

class _AllNotesPageState extends State<AllNotesPage> {
  late final TextEditingController _searchController;

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SettingsCubit, SettingsState>(
      builder: (context, settingsState) {
        final fontSize = settingsState.fontSize;
        final scale = fontSize.scaleFactor;

        return CupertinoPageScaffold(
          navigationBar: CupertinoNavigationBar(
            middle: Text(
              'All Notes',
              style: TextStyle(
                fontFamily: '.SF Pro Display',
                fontSize: 18 * scale,
                fontWeight: FontWeight.w600,
              ),
            ),
            previousPageTitle: 'Write',
          ),
          child: SafeArea(
            child: BlocBuilder<NotesCubit, NotesState>(
              builder: (context, notesState) {
                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                      child: CupertinoSearchTextField(
                        controller: _searchController,
                        placeholder: 'Search notes...',
                        style: TextStyle(
                          fontFamily: '.SF Pro Text',
                          fontSize: 15 * scale,
                        ),
                        onChanged: (query) {
                          context.read<NotesCubit>().updateSearch(query);
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                      child: Row(
                        children: [
                          Expanded(
                            child: CupertinoSlidingSegmentedControl<String>(
                              groupValue: notesState.sortBy,
                              children: {
                                'newest': Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                                  child: Text('Newest', style: TextStyle(fontSize: 13 * scale)),
                                ),
                                'oldest': Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                                  child: Text('Oldest', style: TextStyle(fontSize: 13 * scale)),
                                ),
                                'length': Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                                  child: Text('Length', style: TextStyle(fontSize: 13 * scale)),
                                ),
                              },
                              onValueChanged: (val) {
                                if (val != null) {
                                  context.read<NotesCubit>().updateSort(val);
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: notesState.activeNotes.isEmpty
                          ? Center(
                              child: Text(
                                _searchController.text.isEmpty
                                    ? 'No notes yet.'
                                    : 'No matching notes found.',
                                style: AppTheme.dateTextStyle(
                                  CupertinoTheme.of(context).brightness,
                                  fontSize,
                                ),
                              ),
                            )
                          : ListView.separated(
                              itemCount: notesState.activeNotes.length,
                              separatorBuilder: (context, index) => Container(
                                height: 0.5,
                                color: CupertinoColors.separator.resolveFrom(context),
                                margin: const EdgeInsets.only(left: 16.0),
                              ),
                              itemBuilder: (context, index) {
                                final note = notesState.activeNotes[index];
                                return Dismissible(
                                  key: Key('all-${note.uuid}'),
                                  direction: DismissDirection.endToStart,
                                  background: Container(
                                    color: CupertinoColors.destructiveRed.resolveFrom(context),
                                    alignment: Alignment.centerRight,
                                    padding: const EdgeInsets.only(right: 24.0),
                                    child: const Icon(
                                      CupertinoIcons.delete,
                                      color: CupertinoColors.white,
                                    ),
                                  ),
                                  onDismissed: (direction) {
                                    context.read<NotesCubit>().softDelete(note.uuid);
                                  },
                                  child: GestureDetector(
                                    behavior: HitTestBehavior.opaque,
                                    onTap: () => _showNoteReader(context, note.text, note.createdAt, fontSize),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 14.0),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            note.text,
                                            maxLines: 3,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              fontFamily: '.SF Pro Text',
                                              fontSize: 16 * scale,
                                              height: 1.4,
                                            ),
                                          ),
                                          const SizedBox(height: 6),
                                          Text(
                                            DateFormatter.formatForDisplay(note.createdAt),
                                            style: AppTheme.dateTextStyle(
                                              CupertinoTheme.of(context).brightness,
                                              fontSize,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                );
              },
            ),
          ),
        );
      },
    );
  }

  void _showNoteReader(BuildContext context, String text, DateTime createdAt, AppFontSize fontSize) {
    showCupertinoModalPopup(
      context: context,
      builder: (context) => CupertinoPageScaffold(
        navigationBar: CupertinoNavigationBar(
          middle: Text(DateFormatter.formatForDisplay(createdAt)),
          trailing: CupertinoButton(
            padding: EdgeInsets.zero,
            child: const Text('Close'),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: SelectionArea(
              child: Text(
                text,
                style: AppTheme.noteTextStyle(
                  CupertinoTheme.of(context).brightness,
                  fontSize,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
