import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../settings/presentation/blocs/settings_cubit.dart';
import '../../../settings/presentation/blocs/settings_state.dart';
import '../../../settings/presentation/pages/settings_page.dart';
import '../blocs/notes_cubit.dart';
import '../widgets/note_input_field.dart';
import '../widgets/recent_notes_sheet.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SettingsCubit, SettingsState>(
      builder: (context, settingsState) {
        final fontSizeFactor = settingsState.fontSize.scaleFactor;
        final inputFontSize = 18.0 * fontSizeFactor;

        return CupertinoPageScaffold(
          child: SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CupertinoButton(
                        padding: EdgeInsets.zero,
                        child: const Icon(
                          CupertinoIcons.settings,
                          size: 24,
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            CupertinoPageRoute(
                              builder: (_) => const SettingsPage(),
                            ),
                          );
                        },
                      ),
                      CupertinoButton(
                        padding: EdgeInsets.zero,
                        child: const Icon(
                          CupertinoIcons.clock,
                          size: 24,
                        ),
                        onPressed: () {
                          showCupertinoModalPopup(
                            context: context,
                            builder: (context) => const RecentNotesSheet(),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: NoteInputField(
                    fontSize: inputFontSize,
                    onSubmitted: (text) {
                      context.read<NotesCubit>().saveNoteText(text);
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
