import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';

class NoteInputField extends StatefulWidget {
  final Function(String) onSubmitted;
  final double fontSize;

  const NoteInputField({
    super.key,
    required this.onSubmitted,
    required this.fontSize,
  });

  @override
  State<NoteInputField> createState() => _NoteInputFieldState();
}

class _NoteInputFieldState extends State<NoteInputField>
    with SingleTickerProviderStateMixin {
  late final TextEditingController _controller;
  late final FocusNode _focusNode;
  late final AnimationController _animationController;
  late final Animation<double> _fadeAnimation;
  late final Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController();
    _focusNode = FocusNode();
    
    _controller.addListener(_onTextChanged);

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );

    _fadeAnimation = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.94).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _controller.removeListener(_onTextChanged);
    _controller.dispose();
    _focusNode.dispose();
    _animationController.dispose();
    super.dispose();
  }

  void _onTextChanged() {
    final text = _controller.text;
    if (text.endsWith('\n')) {
      final trimmedText = text.substring(0, text.length - 1);
      _submitNote(trimmedText);
    }
  }

  void _submitNote(String text) {
    if (text.trim().isEmpty) {
      _controller.clear();
      return;
    }

    widget.onSubmitted(text);

    // Run animation
    _animationController.forward().then((_) {
      _controller.clear();
      _animationController.reset();
      // Ensure cursor remains active
      _focusNode.requestFocus();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Focus(
      onKeyEvent: (node, event) {
        if (event is KeyDownEvent && event.logicalKey == LogicalKeyboardKey.enter) {
          _submitNote(_controller.text);
          return KeyEventResult.handled;
        }
        return KeyEventResult.ignored;
      },
      child: AnimatedBuilder(
        animation: _animationController,
        builder: (context, child) {
          return Opacity(
            opacity: _fadeAnimation.value,
            child: Transform.scale(
              scale: _scaleAnimation.value,
              child: child,
            ),
          );
        },
        child: CupertinoTextField.borderless(
          controller: _controller,
          focusNode: _focusNode,
          autofocus: true,
          maxLines: null,
          keyboardType: TextInputType.multiline,
          textInputAction: TextInputAction.done,
          onSubmitted: (value) => _submitNote(value),
          style: TextStyle(
            fontFamily: '.SF Pro Text',
            fontSize: widget.fontSize,
            height: 1.5,
            color: CupertinoTheme.of(context).textTheme.textStyle.color,
          ),
          placeholder: 'Write...',
          placeholderStyle: TextStyle(
            fontFamily: '.SF Pro Text',
            fontSize: widget.fontSize,
            color: CupertinoTheme.of(context).brightness == Brightness.dark
                ? CupertinoColors.placeholderTextColor
                : CupertinoColors.secondaryLabel,
          ),
          cursorColor: CupertinoTheme.of(context).primaryColor,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        ),
      ),
    );
  }
}
