import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart' show Dismissible, DismissDirection;
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../settings/presentation/blocs/settings_cubit.dart';
import '../../../settings/presentation/blocs/settings_state.dart';
import '../blocs/notes_cubit.dart';
import '../blocs/notes_state.dart';
import '../pages/all_notes_page.dart';

class RecentNotesSheet extends StatelessWidget {
  const RecentNotesSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SettingsCubit, SettingsState>(
      builder: (context, settingsState) {
        final fontSize = settingsState.fontSize;
        final scale = fontSize.scaleFactor;
        
        return Container(
          decoration: BoxDecoration(
            color: CupertinoTheme.of(context).scaffoldBackgroundColor,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: SafeArea(
            bottom: true,
            child: Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Center(
                    child: Container(
                      width: 36,
                      height: 5,
                      decoration: BoxDecoration(
                        color: CupertinoColors.systemGray4.resolveFrom(context),
                        borderRadius: BorderRadius.circular(2.5),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24.0),
                    child: Text(
                      'Recent Notes',
                      style: TextStyle(
                        fontFamily: '.SF Pro Display',
                        fontSize: 20 * scale,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  
                  BlocBuilder<NotesCubit, NotesState>(
                    builder: (context, notesState) {
                      final notes = notesState.recentNotes;
                      
                      if (notes.isEmpty) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32.0),
                          child: Text(
                            'No notes yet.',
                            style: AppTheme.dateTextStyle(
                              CupertinoTheme.of(context).brightness,
                              fontSize,
                            ),
                          ),
                        );
                      }
                      
                      return ListView.separated(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: notes.length,
                        separatorBuilder: (context, index) => Container(
                          height: 0.5,
                          color: CupertinoColors.separator.resolveFrom(context),
                          margin: const EdgeInsets.only(left: 24.0),
                        ),
                        itemBuilder: (context, index) {
                          final note = notes[index];
                          return Dismissible(
                            key: Key('recent-${note.uuid}'),
                            direction: DismissDirection.endToStart,
                            background: Container(
                              color: CupertinoColors.destructiveRed.resolveFrom(context),
                              alignment: Alignment.centerRight,
                              padding: const EdgeInsets.only(right: 24.0),
                              child: const Icon(
                                CupertinoIcons.delete,
                                color: CupertinoColors.white,
                              ),
                            ),
                            onDismissed: (direction) {
                              context.read<NotesCubit>().softDelete(note.uuid);
                            },
                            child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () => _showNoteReader(context, note.text, note.createdAt, fontSize),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 14.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      note.text,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontFamily: '.SF Pro Text',
                                        fontSize: 16 * scale,
                                        height: 1.4,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      DateFormatter.formatForDisplay(note.createdAt),
                                      style: AppTheme.dateTextStyle(
                                        CupertinoTheme.of(context).brightness,
                                        fontSize,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                  
                  const SizedBox(height: 16),
                  
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 8.0),
                    child: CupertinoButton(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      color: CupertinoColors.systemFill.resolveFrom(context),
                      borderRadius: BorderRadius.circular(12),
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          CupertinoPageRoute(
                            builder: (_) => const AllNotesPage(),
                          ),
                        );
                      },
                      child: Text(
                        'Show All',
                        style: TextStyle(
                          fontFamily: '.SF Pro Text',
                          fontSize: 16 * scale,
                          fontWeight: FontWeight.w600,
                          color: CupertinoTheme.of(context).textTheme.textStyle.color,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showNoteReader(BuildContext context, String text, DateTime createdAt, AppFontSize fontSize) {
    showCupertinoModalPopup(
      context: context,
      builder: (context) => CupertinoPageScaffold(
        navigationBar: CupertinoNavigationBar(
          middle: Text(DateFormatter.formatForDisplay(createdAt)),
          trailing: CupertinoButton(
            padding: EdgeInsets.zero,
            child: const Text('Close'),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: SelectionArea(
              child: Text(
                text,
                style: AppTheme.noteTextStyle(
                  CupertinoTheme.of(context).brightness,
                  fontSize,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
