import '../entities/note.dart';

abstract class NotesRepository {
  Future<void> saveNote(Note note);
  Future<List<Note>> getRecentNotes(int limit);
  Future<List<Note>> getAllActiveNotes({String? searchQuery, String? sortBy});
  Future<List<Note>> getSoftDeletedNotes();
  Future<void> softDeleteNote(String uuid);
  Future<void> restoreNote(String uuid);
  Future<void> hardDeleteNote(String uuid);
  Future<void> hardDeleteAllExpiredTrash();
}
