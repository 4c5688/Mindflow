import 'package:sqflite/sqflite.dart';
import '../../../../core/database/database_helper.dart';
import '../../domain/entities/note.dart';
import '../../domain/repositories/notes_repository.dart';
import '../models/note_model.dart';

class NotesRepositoryImpl implements NotesRepository {
  final DatabaseHelper _dbHelper;

  NotesRepositoryImpl({DatabaseHelper? dbHelper})
      : _dbHelper = dbHelper ?? DatabaseHelper.instance;

  @override
  Future<void> saveNote(Note note) async {
    final db = await _dbHelper.database;
    final model = NoteModel.fromEntity(note);
    await db.insert(
      'notes',
      model.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  @override
  Future<List<Note>> getRecentNotes(int limit) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'notes',
      where: 'is_deleted = 0',
      orderBy: 'created_at DESC',
      limit: limit,
    );
    return maps.map((map) => NoteModel.fromMap(map)).toList();
  }

  @override
  Future<List<Note>> getAllActiveNotes({String? searchQuery, String? sortBy}) async {
    final db = await _dbHelper.database;
    
    String whereClause = 'is_deleted = 0';
    final List<dynamic> whereArgs = [];
    
    if (searchQuery != null && searchQuery.trim().isNotEmpty) {
      whereClause += ' AND text LIKE ?';
      whereArgs.add('%$searchQuery%');
    }

    String orderBy;
    switch (sortBy) {
      case 'oldest':
        orderBy = 'created_at ASC';
        break;
      case 'length':
        orderBy = 'LENGTH(text) DESC';
        break;
      case 'newest':
      default:
        orderBy = 'created_at DESC';
        break;
    }

    final List<Map<String, dynamic>> maps = await db.query(
      'notes',
      where: whereClause,
      whereArgs: whereArgs,
      orderBy: orderBy,
    );
    return maps.map((map) => NoteModel.fromMap(map)).toList();
  }

  @override
  Future<List<Note>> getSoftDeletedNotes() async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'notes',
      where: 'is_deleted = 1',
      orderBy: 'deleted_at DESC',
    );
    return maps.map((map) => NoteModel.fromMap(map)).toList();
  }

  @override
  Future<void> softDeleteNote(String uuid) async {
    final db = await _dbHelper.database;
    await db.update(
      'notes',
      {
        'is_deleted': 1,
        'deleted_at': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'uuid = ?',
      whereArgs: [uuid],
    );
  }

  @override
  Future<void> restoreNote(String uuid) async {
    final db = await _dbHelper.database;
    await db.update(
      'notes',
      {
        'is_deleted': 0,
        'deleted_at': null,
      },
      where: 'uuid = ?',
      whereArgs: [uuid],
    );
  }

  @override
  Future<void> hardDeleteNote(String uuid) async {
    final db = await _dbHelper.database;
    await db.delete(
      'notes',
      where: 'uuid = ?',
      whereArgs: [uuid],
    );
  }

  @override
  Future<void> hardDeleteAllExpiredTrash() async {
    await _dbHelper.cleanOldDeletedNotes();
  }
}
