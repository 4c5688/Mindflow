import 'package:flutter/cupertino.dart';

enum AppFontSize {
  small,
  medium,
  large,
  extraLarge,
}

extension AppFontSizeExtension on AppFontSize {
  double get scaleFactor {
    switch (this) {
      case AppFontSize.small:
        return 0.85;
      case AppFontSize.medium:
        return 1.0;
      case AppFontSize.large:
        return 1.25;
      case AppFontSize.extraLarge:
        return 1.5;
    }
  }

  String get displayName {
    switch (this) {
      case AppFontSize.small:
        return 'Small';
      case AppFontSize.medium:
        return 'Default';
      case AppFontSize.large:
        return 'Large';
      case AppFontSize.extraLarge:
        return 'Extra Large';
    }
  }

  static AppFontSize fromString(String val) {
    return AppFontSize.values.firstWhere(
      (e) => e.name == val,
      orElse: () => AppFontSize.medium,
    );
  }
}

class AppTheme {
  // Pure minimalist colors
  static const Color lightBackground = CupertinoColors.white;
  static const Color darkBackground = CupertinoColors.black;

  static const Color lightText = CupertinoColors.black;
  static const Color darkText = CupertinoColors.white;

  static const Color lightSubtleText = CupertinoColors.secondaryLabel;
  static const Color darkSubtleText = CupertinoColors.placeholderTextColor;

  static CupertinoThemeData getTheme(Brightness brightness, AppFontSize fontSize) {
    final isDark = brightness == Brightness.dark;
    final baseTextColor = isDark ? darkText : lightText;
    final scale = fontSize.scaleFactor;

    return CupertinoThemeData(
      brightness: brightness,
      primaryColor: isDark ? CupertinoColors.white : CupertinoColors.black,
      backgroundColor: isDark ? darkBackground : lightBackground,
      scaffoldBackgroundColor: isDark ? darkBackground : lightBackground,
      textTheme: CupertinoTextThemeData(
        textStyle: TextStyle(
          fontFamily: '.SF Pro Text',
          fontSize: 16 * scale,
          color: baseTextColor,
          height: 1.5,
          letterSpacing: -0.3,
        ),
        actionTextStyle: TextStyle(
          fontFamily: '.SF Pro Text',
          fontSize: 16 * scale,
          color: isDark ? CupertinoColors.white : CupertinoColors.black,
          fontWeight: FontWeight.w400,
        ),
        navTitleTextStyle: TextStyle(
          fontFamily: '.SF Pro Display',
          fontSize: 18 * scale,
          fontWeight: FontWeight.w600,
          color: baseTextColor,
          letterSpacing: -0.4,
        ),
        navLargeTitleTextStyle: TextStyle(
          fontFamily: '.SF Pro Display',
          fontSize: 34 * scale,
          fontWeight: FontWeight.bold,
          color: baseTextColor,
          letterSpacing: -1.0,
        ),
      ),
    );
  }

  // Helper styles that scale
  static TextStyle noteTextStyle(Brightness brightness, AppFontSize fontSize) {
    final isDark = brightness == Brightness.dark;
    return TextStyle(
      fontFamily: '.SF Pro Text',
      fontSize: 18 * fontSize.scaleFactor,
      color: isDark ? darkText : lightText,
      height: 1.6,
      letterSpacing: -0.3,
    );
  }

  static TextStyle dateTextStyle(Brightness brightness, AppFontSize fontSize) {
    final isDark = brightness == Brightness.dark;
    return TextStyle(
      fontFamily: '.SF Pro Text',
      fontSize: 12 * fontSize.scaleFactor,
      color: isDark ? darkSubtleText : lightSubtleText,
      fontWeight: FontWeight.w400,
    );
  }
}
