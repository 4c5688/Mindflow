import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('notes.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
      onOpen: _onOpen,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    // 1. Create notes table
    await db.execute('''
      CREATE TABLE notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        uuid TEXT NOT NULL UNIQUE,
        text TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        updated_at INTEGER,
        is_deleted INTEGER DEFAULT 0,
        deleted_at INTEGER
      )
    ''');

    // 2. Create required indexes for fast queries
    await db.execute('CREATE INDEX idx_notes_created_at ON notes(created_at)');
    await db.execute('CREATE INDEX idx_notes_is_deleted ON notes(is_deleted)');
    await db.execute('CREATE INDEX idx_notes_deleted_at ON notes(deleted_at)');

    // 3. Create settings table for local-only settings
    await db.execute('''
      CREATE TABLE settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');

    // Insert default settings
    await db.insert('settings', {'key': 'theme_mode', 'value': 'system'});
    await db.insert('settings', {'key': 'font_size', 'value': 'medium'});
  }

  Future<void> _onOpen(Database db) async {
    // Execute hard delete for notes soft-deleted more than 30 days ago on startup
    await cleanOldDeletedNotes(db);
  }

  /// Performs hard delete on notes soft-deleted more than 30 days ago.
  Future<int> cleanOldDeletedNotes([Database? db]) async {
    final activeDb = db ?? await database;
    final thirtyDaysAgo = DateTime.now().subtract(const Duration(days: 30)).millisecondsSinceEpoch;
    
    return await activeDb.delete(
      'notes',
      where: 'is_deleted = 1 AND deleted_at < ?',
      whereArgs: [thirtyDaysAgo],
    );
  }

  Future<void> close() async {
    final db = _database;
    if (db != null) {
      await db.close();
    }
  }
}
