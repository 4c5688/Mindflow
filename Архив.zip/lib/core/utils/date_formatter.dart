import 'package:intl/intl.dart';

class DateFormatter {
  static final DateFormat _exportFormat = DateFormat('yyyy-MM-dd_HH-mm-ss');
  static final DateFormat _displayFormat = DateFormat('d MMM yyyy, HH:mm');

  /// Formats note creation date for the markdown filename.
  /// Example: 2026-06-26_14-35-18.md
  static String formatForExport(DateTime dateTime) {
    return '${_exportFormat.format(dateTime)}.md';
  }

  /// Formats note creation date for UI display.
  /// Example: 26 Jun 2026, 14:35
  static String formatForDisplay(DateTime dateTime) {
    return _displayFormat.format(dateTime);
  }
}
