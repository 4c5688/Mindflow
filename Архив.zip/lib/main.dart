import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'core/database/database_helper.dart';
import 'core/theme/app_theme.dart';
import 'features/notes/data/repositories/notes_repository_impl.dart';
import 'features/notes/presentation/blocs/notes_cubit.dart';
import 'features/notes/presentation/pages/home_page.dart';
import 'features/settings/data/repositories/settings_repository_impl.dart';
import 'features/settings/presentation/blocs/settings_cubit.dart';
import 'features/settings/presentation/blocs/settings_state.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Eagerly initialize SQLite DB to trigger startup configuration and cleanup
  final dbHelper = DatabaseHelper.instance;
  await dbHelper.database;

  final notesRepository = NotesRepositoryImpl(dbHelper: dbHelper);
  final settingsRepository = SettingsRepositoryImpl(dbHelper: dbHelper);

  runApp(
    MultiBlocProvider(
      providers: [
        BlocProvider<NotesCubit>(
          create: (_) => NotesCubit(notesRepository),
        ),
        BlocProvider<SettingsCubit>(
          create: (_) => SettingsCubit(settingsRepository, notesRepository),
        ),
      ],
      child: const MainApp(),
    ),
  );
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SettingsCubit, SettingsState>(
      builder: (context, settingsState) {
        final brightness = _resolveBrightness(settingsState.themeMode);
        
        return CupertinoApp(
          title: 'MindShot',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.getTheme(brightness, settingsState.fontSize),
          home: const HomePage(),
        );
      },
    );
  }

  Brightness _resolveBrightness(String themeMode) {
    if (themeMode == 'light') return Brightness.light;
    if (themeMode == 'dark') return Brightness.dark;
    
    // Resolve platform system brightness
    return WidgetsBinding.instance.platformDispatcher.platformBrightness;
  }
}
